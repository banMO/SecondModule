﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace JalaFoundation.Dev23.Practice3.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
