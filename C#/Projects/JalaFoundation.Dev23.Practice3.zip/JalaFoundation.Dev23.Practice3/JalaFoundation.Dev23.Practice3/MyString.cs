﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JalaFoundation.Dev23.Practice3;
namespace JalaFoundation.Dev23.Practice3
{
   public class MyString
    {
        public void Method1()
        {
            var message = "";
            string first = message.GetFirstLetter();
 
        }

    }
}
