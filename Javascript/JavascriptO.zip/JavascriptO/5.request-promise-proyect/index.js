// como no es una libreria ni dependencia, hay que darle
// el path relativo.
var argv = require('yargs').argv;
var defineIt = require('./define-it.js');
var chalk = require('chalk');

if (!argv.define) {
    throw new Error('Please provide a word: --define=<word>');
}

//var wordsArray = argv.define.split(',');

console.log(argv.define);

defineIt.define(argv.define)
    .then(results => {
        results.forEach( result => {
            result.forEach( definition => {
                console.log(chalk.green(definition.word));
                console.log(chalk.red(definition.text));

                console.log(chalk.yellow(definition.exampleUses));
            })
        })

        /*results.forEach(element => {
            console.log(chalk.green(element.word));
            console.log(chalk.red(element.text));

            console.log(chalk.yellow(element.exampleUses));
        })*/
    })
    .catch(err => {
        console.log(err);
    });