var rp = require('request-promise');

function search(word) {
    var options = {
        uri: 'http://api.wordnik.com/v4/word.json/' + word + '/definitions',
        qs: {
            includeRelated: true,
            limit: 200,
            useCanonical: false,
            includeTags: false,
            api_key: 'a2a73e7b926c924fad7001ca3111acd55af2ffabf50eb4ae5' // -> uri + '?access_token=xxxxx%20xxxxx'
        },
        json: true // Automatically parses the JSON string in the response
    };

    return rp(options);
}

module.exports = {
    search
};