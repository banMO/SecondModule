var client = require('./client.js');
var storage = require('./storage.js');


function promiseProcess(word){
    return storage.find(word)
    .then(results => {

        if (results.length > 0) {
            return results;
        }

        return client.search(word)
            .then(results => {
                storage.save(results);
                return results;
            });

    });   
}

function define(words) {
    var arrWords = words.map((element)=>{
        return promiseProcess(element)
    })

    return Promise.all(arrWords) 
}

module.exports = {
    define
}