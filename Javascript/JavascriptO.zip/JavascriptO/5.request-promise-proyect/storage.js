const Sequelize = require('sequelize');

const sequelize = new Sequelize('dictionary', 'sa', 'Extreme*183761', {
    host: 'localhost',
    dialect: 'mssql',
    port: 1433,
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
    },
});

sequelize.authenticate()
    .then(() => {
        console.log('Connection has been established successfully.');
    })
    .catch(err => {
        console.error('Unable to connect to the database:', err);
    });

const Word = sequelize.define('word', {
    id: {
        type: Sequelize.INTEGER, 
        primaryKey: true, 
        autoIncrement: true
    },
    word: Sequelize.STRING,
    text: Sequelize.TEXT,
    partOfSpeech: Sequelize.TEXT,
    exampleUses: {
        type: Sequelize.TEXT,
        allowNull: true,
    },
});

// force: true will drop the table if it already exists
Word.sync({force: false})
    .then(() => {
        console.log('synchronized');
});

function find(word) {
    return Word.findAll({
        where: {
            word: word
        }
    });
}

function save(results) {
    results.forEach(element => {
        Word.create({
            word: element.word,
            text: element.text,
            partOfSpeech: element.partOfSpeech,
            exampleUses: element.exampleUses.toString()
        });
    });
}

module.exports = {
    find,
    save
};