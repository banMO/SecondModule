const fs = require('fs');

console.log('step 1');

// non-blocking
fs.readFile('C:\\Users\\Administrator\\Desktop\\readme.txt', 'utf-8', (err, data) => {
  if (err) throw err;
  console.log(data);
  console.log('step 2');
});

console.log('step 3');