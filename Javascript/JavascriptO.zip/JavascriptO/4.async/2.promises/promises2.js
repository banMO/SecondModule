function connectToDatabase(n) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve('successfully connected to db ' + n);
        }, 2000);
    });

    // esta forma tambien funciona.
    // return Promise.resolve('successfully connected!');

    // return Promise.reject('Error!!');
}

const promises = [
    connectToDatabase(1),
    connectToDatabase(2),
    connectToDatabase(3),
    connectToDatabase(4),
    connectToDatabase(5)
];

Promise.all(promises)
    .then(results => console.log(results))
    .catch(err => console.log(err));