function connectToDatabase() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve('successfully connected!');
        }, 2000);
    });

    // esta forma tambien funciona.
    // return Promise.resolve('successfully connected!');

    // return Promise.reject('Error!!');
}

function getUser() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve('Juan Perez');
        }, 2000)
    });
}

function getComments() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve('Buen Post!!');
        }, 2000)
    });
}

console.log(1);

connectToDatabase()
    .then(result => {
        console.log(3);
        console.log(result);

        return getUser();
        // no es obligado retorna una promesa. Esto tambien funciona
        // return { 'name': 'pedro perez' };
    })
    .then(user => {
        console.log(user);
        return getComments();
    })
    .then(comments => {
        console.log(comments);
    })
    .catch(err => {
        console.error(err);
    });

console.log(2);
