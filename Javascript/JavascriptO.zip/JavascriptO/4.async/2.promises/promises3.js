var fs = require('fs');

function promisify(obj, method, ...m) {
    return new Promise((resolve, reject) => {
        obj[method](...m, (err, data) => {
            if (err)
                reject(err);

            resolve(data);
        });
    });
}

promisify(fs, 'readFile', 'C:\\Users\\Administrator\\Desktop\\readme.txt', 'utf-8')
    .then(file => console.log(file))
    .catch(err => console.log(err));

// rest - spread
// var a = [1, 2, 3];
// console.log(...a);

// function x(...m) {
//     console.log(m);
// }

// x(1, 2, 3, 4, 5, 6, 7, 8);