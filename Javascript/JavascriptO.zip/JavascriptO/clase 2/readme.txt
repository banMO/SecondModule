Javascript es multiparadigma. Admite poo y programacion funcional.

Las funciones deben ser lo mas limpias posibles.

En lo posible usar arrow functions y los metodos de programacion functional: finde, some, every.