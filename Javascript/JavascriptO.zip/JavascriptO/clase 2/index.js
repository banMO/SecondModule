// imperative
for (let i = 0; i < 10; i++) {
	console.log(i);
}

const arr = [1, 2, 3];
// declarative
arr.forEach(function(el) {
	console.log(el);
});

// currying - partial application
calculate(sum(getNumber()));

var person = {
	name: 'Jorge'
};

function doSomething(x) {
	person.age = x;
}