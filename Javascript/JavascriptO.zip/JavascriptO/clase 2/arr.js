const arr1 = [1, 2, '', true, function() {}];
const arr2 = new Array();

arr1.push()
arr1.slice()
arr1.unshift()

const arr3 = [1, 2, 3, 4, 5, 6];
arr3.forEach(el => {
	console.log('el', el);
});

// ES6
arr3.find(el => el === 3);

// itera el array y devuelve un array nuevo.
const b = arr3.map(el => el * 10);
const c = arr3.map(el => ({ n: el}));

// devuelve un nuevo array filtrado
const even = arr3.filter(el => el % 2 === 0);
console.log(even);

// devuelve true o false si todos los elementos cumplen la condicion.
// ES6
const biggerThanZero = arr3.every(el => el > 0);

// ES6
const someBiggerThanZero = arr3.some(el => el > 3);
console.log(someBiggerThanZero);

var suma = arr3.reduce((curr, next) => curr += next);
console.log(suma)

var suma2 = arr3.reduce((curr, next) => curr += next, 100);
console.log(suma2);

arr3.map(el => el * 9)
	.filter(el => el % 2 === 0);


// filter, map, some
function filter(arr, cb) {
	var new = [];

	for (let i = 0; i < arr.length; i++) {
		if(cb(arr[i], i, arr))
			new.push(arr[i]);
	}
	return new;
}

filter([1, 2, 3, 4, 5], (el, index, arr) => {
	console.log(el, index, arr);
	return el % 2 !== 0;
});
