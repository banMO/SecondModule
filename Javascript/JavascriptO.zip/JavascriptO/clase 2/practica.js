// filter, map, some
function filter(arr, cb) {
	var newArr = [];

	for (let i = 0; i < arr.length; i++) {
		if(cb(arr[i], i, arr))
			newArr.push(arr[i]);
	}
	return newArr;
}

function filter2(arr, cb) {
	var results = [];
	
	arr.forEach((el, index) => {
		if (cb(el, index, arr)) {
			results.push(el);
		}
	});

	return results;
}

// devuelve un nuevo arreglo
function map(arr, cb) {
	var newArr = [];

	for (let i = 0; i < arr.length; i++) {
		newArr.push(cb(arr[i], i, arr));
	}

	return newArr;
}

function map2(arr, cb) {
	var results = [];

	arr.forEach((el, index) => {
		results.push(cb(el, index, arr));
	});

	return results;
}

function some(arr, cb) {
	for (let i = 0; i < arr.length; i++) {
		if (cb(arr[i], i, arr))
			return true;
	}

	return false;
}

var filtrados = filter([1, 2, 3, 4, 5], (el, index, arr) => {
	console.log(el, index, arr);
	return el % 2 !== 0;
});

const filtradosMap = map([1, 2, 3, 4, 5], (el, index, arr) => {
	return el * 2;
});

var someBiggerThanFour = some([1, 2, 3, 4, 3], (el, index, arr) => {
	return el > 4;
});

console.log(filtrados);
console.log(filtradosMap);
console.log(someBiggerThanFour);