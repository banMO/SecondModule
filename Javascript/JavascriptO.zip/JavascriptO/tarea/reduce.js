function reduce(arr, cb, initialValue) {
	var res = arr[0];

	for (let i = 1; i < arr.length; i++) {
		res = cb(res, arr[i]);
	}

	if (initialValue)
		res += initialValue;

	return res;
}


var acum = reduce([1, 2, 3, 4, 5], function(a, b) {
	return a * b;
}, 100);

console.log(acum);
