function reduce(arr, cb, initialValue) {
    var initialIndex;

    if (initialValue) {
        var accumulator = initialValue;
        initialIndex = 0;
    } else {
        var accumulator = arr[0];
        initialIndex = 1;
    }

    for (let i = initialIndex; i < arr.length; i++) {
        accumulator = cb(accumulator, arr[i], i, arr);
    }
    return accumulator;
}


var result1 = reduce([1, 2, 3, 4, 5], (accumulator, currentValue, currentIndex, arr) => {
    return accumulator + currentValue;
});

var result2 = reduce([1, 2, 3, 4, 5], (accumulator, currentValue, currentIndex, arr) => {
    return accumulator + currentValue;
}, 100);

var result3 = reduce([{name: 'jose'}, {name: 'luis'}, {name: 'pablo'}], (accumulator, currentValue, currentIndex, arr) => {
    return {
        name: accumulator.name + ' ' + currentValue.name
    };
});

console.log('result1: ', result1);
console.log('result2: ', result2);
console.log('result3: ', result3);
