var list = {
	limit: 10,
	numberOfTasks: 0,
	tasks: [],
	setLimit: function(limit) {
		this.limit = limit;
	},

	add: function(task) {
		if (this.numberOfTasks < this.limit) {
			console.log('adding task');
			this.tasks.push(task);
			this.numberOfTasks++;
		} else {
			console.log('the list is full');
		}
	},

	delete: function(id) {
		var index = this.getIndex(id);

		if (index > -1) {
			this.tasks.splice(index, 1);
			console.log('deleting element with id %d', id);
		} else {
			console.log('that element does not exist in the list');
		}
	},

	show: function() {
		this.tasks.forEach(function(task) {
			console.log(task);
		})
	},

	changeState: function(id, state) {
		this.getTask(id).state = state;
	},

	getTask: function(id) {
		for (var i = 0; i < this.tasks.length; i++) {
			if (this.tasks[i].id === id) {
				return this.tasks[i];
			}
		}
	},

	getIndex: function(id) {
		for (var i = 0; i < this.tasks.length; i++) {
			if (this.tasks[i].id === id) {
				return i;
			}
		}
	}
};

function createTask(id, name, state = 'pending') {
	return {
		id: id,
		name: name,
		state: state
	};
}

list.setLimit(3);

list.add(createTask(1, 'estudiar javascript'));
list.add(createTask(2, 'estudiar html'));
list.add(createTask(3, 'estudiar ingles'));

list.changeState(2, 'finished');
list.changeState(3, 'in progress');

list.add(createTask(4, 'estudiar ingles'));
list.show();

list.delete(3);
list.delete(10);

console.log('======= after deleting ========');

list.show();