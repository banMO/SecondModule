// ES5 - Constructor Function
function Person(name) {
    this.name = name;
}

Person.prototype.sayHi = function() {
    console.log('hi');
};

// metodos estaticos.
Person.someStaticValue = 'XD';

// siempre se llama con new a una funcion constructora.
var pedro = new Person('pedro');
var jose = new Person('jose');
var carlos = new Person('carlos');

console.log(carlos);