// esto es solo sugar syntactic.
// todas las funciones definidas dentro de la clase se agregar al
// objeto prototype.
// class Person {
//     constructor(name) {
//         this.name = name;
//     }

//     sayHi() {
//         console.log('Hi');
//     }
// }

function Person(name) {
    this.name = name;
}

Person.prototype.sayHi = function() {
    console.log('hi');
};

Person.someStaticValue = 'XD';

function Employee(name, salary) {
    this.salary = salary;
    // ejecuta la function Person() en el context de this.
    Person.call(this, name);
}

// ES6
// Object.setPrototypeOf(Employee.prototype, Person.prototype);

// crea un object nuevo y le setea Person.prototype como su prototype.
Employee.prototype = Object.create(Person.prototype);
Employee.prototype.constructor = Employee;

Employee.prototype.pay = function() {
    console.log('pay!');
};

var carlos = new Employee('carlos', 2000);

carlos.pay();

console.log(carlos);
