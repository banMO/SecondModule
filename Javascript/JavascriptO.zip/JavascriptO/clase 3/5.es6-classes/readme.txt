diferencias entre constructor functions y classes
===================================================

- classes cannot be invoked without new.
- classes can inherit static attributes.
- Syntax sugar
- classes can inherit from other classes and from constructor functions.
- constructor functions can only inherit from constructor functions.