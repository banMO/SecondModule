// ES6 - esto es solo sugar syntactic.
// todas las funciones definidas dentro de la clase se agregar al
// objeto prototype.
class Person {
    constructor(name) {
        this.name = name;
    }

    sayHi() {
        console.log('Hi');
    }
}

Person.someStaticValue = 'XD';

class Employee extends Person {

    constructor(name, salary) 
    {
        super(name);
        this.salary = salary;
        // Person.call(this, name);
    }

    pay() {
        console.log('pay!');
    }
}

var pedro = new Employee('pedro', 1000);

console.log(pedro);

console.log(Employee.someStaticValue);

