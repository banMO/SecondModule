var person = {
    sayHi: function() {
        console.log('Hi');
    },

    sayBye: function() {
        console.log('Bye!');
    }
}

var pedro = {
    name: 'Pedro',
    age: 30
};

Object.setPrototypeOf(pedro, person);

pedro.sayHi();
pedro.sayBye();

console.log('pedro.__proto__: ', pedro.__proto__);
console.log(person === pedro.__proto__);
console.log('getPrototypeOf: ', Object.getPrototypeOf(pedro));