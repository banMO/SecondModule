Boxing
int i = 123;
object o = i;  

lo que hace el boxing es convertir un value type en reference type ya que int es un value type y object es un 
reference type y unboxing viene a ser la conversion de un reference type a un value type.

Unboxing
o = 123;
i = (int)o;  

Cuando usar?
Se puede usar cuando se quiere un sistema de tipo unificado, es decir, los value types y reference types tendran una forma
en comun para representarse.
